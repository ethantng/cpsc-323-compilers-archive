#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <iomanip>

using namespace std;

unordered_map<string, int> symbolTable;
int memoryAddress = 10000;

vector<string> instructions; // assembly instructions storage
int instructionIndex = 1;

void emit(const string& instr) 
{
    instructions.push_back(to_string(instructionIndex++) + " " + instr);
}

void addToSymbolTable(const string& id) //symbol table storage
{
    if (symbolTable.find(id) == symbolTable.end()) 
    {
        symbolTable[id] = memoryAddress++;
    }
}

void parseAssign(const string& id, const string& exprType, const string& value) 
{
    addToSymbolTable(id);

    if (exprType == "int") 
    {
        emit("PUSHI " + value);
    } else if (exprType == "id") 
    {
        emit("PUSHM " + to_string(symbolTable[value]));
    }

    emit("POPM " + to_string(symbolTable[id]));
}

void parseScan(const string& id) 
{
    addToSymbolTable(id);
    emit("SIN");
    emit("POPM " + to_string(symbolTable[id]));
}

void parseWhileLoop() 
{
    int loopStart = instructionIndex;
    emit("LABEL");

    emit("PUSHM " + to_string(symbolTable["i"]));
    emit("PUSHM " + to_string(symbolTable["max"]));
    emit("LEQ");

    int jmpFalseIndex = instructionIndex;
    emit("JMP0 XX"); // placeholder

    emit("PUSHM " + to_string(symbolTable["sum"]));
    emit("PUSHM " + to_string(symbolTable["i"]));
    emit("A");
    emit("POPM " + to_string(symbolTable["sum"]));

    emit("PUSHM " + to_string(symbolTable["i"]));
    emit("PUSHI 1");
    emit("A");
    emit("POPM " + to_string(symbolTable["i"]));

    emit("JMP " + to_string(loopStart));

    // Patch JMP0 target
    int loopEnd = instructionIndex;
    instructions[jmpFalseIndex - 1] = to_string(jmpFalseIndex) + " JMP0 " + to_string(loopEnd);
}

void parsePrintSumPlusMax() 
{
    emit("PUSHM " + to_string(symbolTable["sum"]));
    emit("PUSHM " + to_string(symbolTable["max"]));
    emit("A");
    emit("SOUT");
}

void printInstructions() //printing assembly code
{
    cout << "\nGenerated Assembly Code:\n-------------------------\n";
    for (const auto& line : instructions)
        cout << line << endl;
}

void printSymbolTable() 
{
    cout << "\nSymbol Table:\n----------------------\n";
    cout << left << setw(12) << "Identifier" << setw(18) << "MemoryLocation" << "Type" << endl;
    for (const auto& [id, addr] : symbolTable) 
    {
        cout << left << setw(12) << id << setw(18) << addr << "integer" << endl;
    }
}

//=============================================================================
int main() 
{
    parseAssign("i", "int", "1");
    parseAssign("sum", "int", "0"); //sample
    parseScan("max");

    // while { sum = sum + i; i = i + 1; }
    parseWhileLoop();

    parsePrintSumPlusMax();

    printInstructions(); //assembly
    printSymbolTable(); //symbol table

    return 0;
}
