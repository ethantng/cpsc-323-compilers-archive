#ifndef SYNTAX_H
#define SYNTAX_H

#include <iostream>
#include <vector>
#include <fstream>
#include "lexer.h"

extern std::vector<Token> tokens;  // Declare but do NOT define
extern int currentTokenIndex;
extern bool debug;
extern std::ofstream outputFile;

void parse(std::vector<Token> tokensList, const std::string& fileName);
void Statement();
void Assign();
void Expression();
void Term();
void Factor();
void ExpressionPrime();
void TermPrime();
void match(std::string expectedType);
void error(std::string message);

#endif
