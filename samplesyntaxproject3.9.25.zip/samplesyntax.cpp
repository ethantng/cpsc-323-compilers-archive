#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include "lexer.h"
#include "syntax.h"

using namespace std;

int main() 

{
    vector<string> testArr = 
    {
        "test1.rat25s",
        "test2.rat25s",
        "test3.rat25s",
    };

    for (const string &oFile : testArr) 
    {
        ifstream sourceFile(oFile);
        ofstream outputFile(oFile.substr(10) + ".txt");

        if (!sourceFile) 
        
        {
            cerr << "Error: Cannot open input file: " << oFile << endl;
            continue;
        }

        outputFile << "Token\tLexeme\n-------------------\n";

        vector<Token> tokens;
        Token token;
        while ((token = lexer(sourceFile)).type != "EOF") 
        
        {
            tokens.push_back(token);
            cout << token.type << "\t" << token.lexeme << endl;
            outputFile << setw(15) << left << token.type << token.lexeme << endl;
        }
        tokens.push_back(
            {"EOF", "", -1});

        sourceFile.close();
        outputFile.close();

        // Run Syntax Analyzer
        parse(tokens, oFile);
    }

    return 0;
}
