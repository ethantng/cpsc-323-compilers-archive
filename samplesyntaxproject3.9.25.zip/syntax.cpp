#include "syntax.h"
using namespace std;

vector<Token> tokens;
int currentTokenIndex = 0;
bool debug = true;
ofstream outputFile;

Token peek() 
{
    if (currentTokenIndex < tokens.size()) 
    {
        return tokens[currentTokenIndex];
    }
    return 
    {"EOF", "", -1};
}

Token getNextToken() 
{
    if (currentTokenIndex < tokens.size()) 
    {
        return tokens[currentTokenIndex++];
    }
    return 
    {"EOF", "", -1};
}

void match(string expectedType) 
{
    Token token = peek();

    outputFile << "Token: " << token.type << " Lexeme: " << token.lexeme << endl;

    if (token.type == expectedType) 
    {
        getNextToken();
    } 
    else 
    {
        error("Expected " + expectedType + " but found " + token.lexeme);
    }
}



void error(string message) 
{
    Token token = peek();
    cerr << "Syntax Error: " << message << " at line " << token.line << endl;
    outputFile << "Syntax Error: " << message << " at line " << token.line << endl;
    exit(1);
}

void Statement() 
{
    Token token = peek();

    if (token.type == "Identifier") 
    {
        if (debug) outputFile << "<Statement> -> <Assign>\n";
        Assign();
    }
    else if (token.lexeme == "while") 
    {
        if (debug) outputFile << "<Statement> -> <While Loop>\n";
        match("Keyword");
        match("Separator");
        Expression();
        match("Separator");
        match("Separator");

        while (peek().lexeme != "}") 
        {
            Statement();
        }

        match("Separator");
    }
    else 
    {
        error("Expected Identifier but found " + token.lexeme);
    }
}

void Assign() 
{
    if (debug) outputFile << "<Assign> -> <Identifier> = <Expression> ;\n";
    
    match("Identifier");
    match("Operator");  
    Expression(); 
    match("Separator"); 
}


void Expression() 
{
    if (debug) outputFile << "<Expression> -> <Term> <Expression Prime>\n";
    Term();
    ExpressionPrime();
}


void ExpressionPrime() 
{
    if (peek().lexeme == "+") {
        match("Operator"); // ✅ Print "+" BEFORE rule
        if (debug) outputFile << "<Expression Prime> -> + <Term> <Expression Prime>\n";
        Term();
        ExpressionPrime();
    } else {
        if (debug) outputFile << "<Expression Prime> -> ε\n";
    }
}


void Term() 
{
    if (debug) outputFile << "<Term> -> <Factor> <Term Prime>\n";
    Factor();
    TermPrime();
}


void TermPrime() 
{
    if (debug) outputFile << "<TermPrime> -> ε\n";  // Since there are no more terms, print epsilon
}


void Factor() 
{
    match("Identifier");
    if (debug) outputFile << "<Factor> -> <Identifier>\n";
}


void parse(vector<Token> tokensList, const string& fileName) 
{
    tokens = tokensList;
    currentTokenIndex = 0;
    outputFile.open(fileName + ".txt");

    Statement();

    if (peek().type != "EOF") 
    {
        error("Unexpected tokens at the end of input.");
    }

    outputFile.close();
}
