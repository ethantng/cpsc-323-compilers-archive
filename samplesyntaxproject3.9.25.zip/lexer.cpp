#include "lexer.h"
#include <unordered_set>
#include <fstream>

using namespace std;

unordered_set<string> keywords = {"while", "endwhile", "for", "function", "scan", "integer", "array", "print"};
unordered_set<string> operators = {"<=", "=", ">", "!=", "==", "<", "+", "-", "*", "/"};
unordered_set<string> separators = {"(", ")", ";", "[", "]", "{", "}", "$$"};

Token lexer(ifstream &file) 
{
    char ch;
    string lexeme;
    Token token;
    bool commenting = false;
    int lineNumber = 1;

    while (file.get(ch)) 
    {
        if (ch == '\n') lineNumber++;

        if (ch == '[' && file.peek() == '*') 
        {
            commenting = true;
            file.get(ch);
        } else if (ch == '*' && file.peek() == ']') 
        {
            file.get(ch);
            commenting = false;
            continue;
        }
        if (isspace(ch) || commenting) continue;

        lexeme = ch;

        if (separators.count(lexeme) || ch == '$') 
        {
            if (ch == '$' && file.peek() == '$') 
            {
                file.get(ch);
                lexeme += ch;
            }
            return 
            {"Separator", lexeme, lineNumber};
        }

        if (operators.count(lexeme) || (ch == '<' || ch == '>' || ch == '=')) 
        {
            file.get(ch);
            string doubleOp = lexeme + ch;
            if (operators.count(doubleOp)) return 
            {"Operator", doubleOp, lineNumber};
            else file.unget();
            return 
            {"Operator", lexeme, lineNumber};
        }

        if (isalpha(ch)) 
        {
            while (file.get(ch) && isalnum(ch)) lexeme += ch;
            file.unget();
            if (keywords.count(lexeme)) return 
            {"Keyword", lexeme, lineNumber};
            return 
            {"Identifier", lexeme, lineNumber};
        } else if (isdigit(ch)) 
        {
            while (file.get(ch) && (isdigit(ch) || ch == '.')) lexeme += ch;
            file.unget();
            return 
            {"Integer", lexeme, lineNumber};
        }
    }
    
    return 
    {"EOF", "", lineNumber};
}
