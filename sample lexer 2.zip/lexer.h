#ifndef LEXER_H
#define LEXER_H

#include <iostream>
#include <fstream>
#include <unordered_set>
#include <vector>

using namespace std;

// Token structure
struct Token
{
    string type;
    string lexeme;
};

// Declare global variables (extern prevents multiple definitions)
extern unordered_set<string> keywords;
extern unordered_set<string> operators;
extern unordered_set<string> separators;

// Function prototypes (no definitions)
bool fsmIdentifier(const string &str);
bool fsmInteger(const string &str);
bool fsmReal(const string &str);
Token lexer(ifstream &file);

#endif // LEXER_H
