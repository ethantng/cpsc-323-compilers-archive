#include "lexer.h"

unordered_set<string> keywords = {"while", "endwhile", "for", "function", "scan", "integer", "array", "print"};
unordered_set<string> operators = {"<=", "=", ">", "!=", "==", "<", ">", "+", "-", "*", "/"};
unordered_set<string> separators = {"(", ")", ";", "[", "]", "{", "}", "$$"};

// Define FSM functions
bool fsmIdentifier(const string &str)
{
    // FSM for Rat25s identifier: starts with a letter, followed by letters or digits
    // identifies valid identifiers, ensures it starts with a letter, digit, or underscore
    if (str.empty() || !isalpha(str[0]) && str[0] != '_')
        return false;

    if (keywords.count(str)) 
        return false;

    for (char ch : str)
    {
        if (!isalnum(ch) && ch != '_')
            return false;
    }
    return true;
}

bool fsmInteger(const string &str)  
{
    //handles signed integers
    //determines if there is a valid integer
    if (str.empty())
        return false;

    size_t i = 0;
    if (str[0] == '+' || str[0] == '-') // allows leading + or -
        i++;

    if (i == str.size())
        return false;

    for (; i < str.size(); i++)
    {
        if (!isdigit(str[i]))
            return false;
    }
    return true;
}

bool fsmReal(const string &str)
{
    //checks valid string
    //requires digits before and after decimal
    if (str.empty()) return false;

    size_t i = 0;
    if (str[0] == '+' || str[0] == '-') // allows leading + or -
        i++;

    bool hasDecimal = false, hasDigitBeforeDecimal = false, hasDigitAfterDecimal = false;

    for (; i < str.size(); i++)
    {
        if (isdigit(str[i]))
        {
            if (!hasDecimal)
                hasDigitBeforeDecimal = true;
            else
                hasDigitAfterDecimal = true;
        }
        else if (str[i] == '.')
        {
            if (hasDecimal) return false;
            hasDecimal = true;
        }
        else return false;
    }
    return hasDecimal && hasDigitBeforeDecimal && hasDigitAfterDecimal;
}

Token lexer(ifstream &file)
{
    //processes tokens
    char ch;
    string lexeme;
    Token token;
    bool commenting = false;

    while (file.get(ch)) // reads characters from file
    {
        if (ch == '[' && file.peek() == '*')
        {
            commenting = true;
            file.get(ch);
        }
        else if (ch == '*' && file.peek() == ']')
        {
            file.get(ch);
            commenting = false;
            continue; //skip to next iteration
        }
        
        // skip whitespace and commented sections
        if (isspace(ch) || commenting)
            continue;

        lexeme = ch;
    
        
        //check for separtors
        if (separators.count(lexeme) || ch == '$')
        {
            if (ch == '$' && file.peek() == '$') //see if the separator is '$$'
            {
                file.get(ch);
                lexeme += ch;
            }
            else if (ch == '$' && file.peek() != ' ') //if separator is not '$$'
            {
                return {"Unknown", lexeme};
            }
            return {"Separator", lexeme};
        }

        //checking for operators
        if (operators.count(lexeme) || (ch == '<' || ch == '>' || ch == '='))
        {
            file.get(ch); // look for possible double operators
            string doubleOp = lexeme + ch;
            if (operators.count(doubleOp))
            {
                return {"Operator", doubleOp}; //return double operators
            }
            else
            {
                file.unget();
            }
            return {"Operator", lexeme};
        }
        
        //process identifiers and keywords that start with a letter
        if (isalpha(ch))
        {
            while (file.get(ch) && isalnum(ch)) // continue reading alphanumeric characters
            {
                lexeme += ch;
            }
            file.unget(); //put back last char that's not part of the lexeme

            if (keywords.count(lexeme)) // checks if the lexeme is a keyword or identifier
                return {"Keyword", lexeme};
            else if (fsmIdentifier(lexeme))
                return {"Identifier", lexeme};
        }
        
        //process numbers that are integers and reals
        else if (isdigit(ch))
        {
            while (file.get(ch) && (isdigit(ch) || ch == '.'))
            {
                lexeme += ch;
            }
            file.unget(); //put back last char that's not part of the number

            if (fsmReal(lexeme))
                return {"Real", lexeme};
            if (fsmInteger(lexeme))
                return {"Integer", lexeme};
        }
    }
    return {"EOF", ""}; //return EOF token when file is completely read
}
